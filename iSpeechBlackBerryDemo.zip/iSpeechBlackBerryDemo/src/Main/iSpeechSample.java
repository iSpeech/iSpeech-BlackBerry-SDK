package Main;
import Forms.HomeForm;
import net.rim.device.api.ui.UiApplication;

public class iSpeechSample extends UiApplication
{
	public static String _APIKey ="developerdemokeydeveloperdemokey"; //your api key, http://www.ispeech.org/developers
	public static boolean _Production = true; // false is "Mobile Development" and true is "Mobile Production"
	
	public static void main (String [] args)
	{
		iSpeechSample sample = new iSpeechSample();
		sample.enterEventDispatcher();		
	}
	public iSpeechSample()
	{		
		pushScreen(new HomeForm());
	}

}

package Forms;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.XYEdges;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.container.HorizontalFieldManager;
import net.rim.device.api.ui.container.MainScreen;

import org.iSpeech.SpeechRecognizer;
import org.iSpeech.SpeechRecognizer.SpeechRecognizerEvent;
import org.iSpeech.SpeechResult;
import org.iSpeech.SpeechSynthesis;
import org.iSpeech.SpeechSynthesis.SpeechSynthesisEvent;

import Utils.PhoneUtils;


public class ASRListForm extends MainScreen implements SpeechRecognizerEvent,SpeechSynthesisEvent,FieldChangeListener
{
	private SpeechRecognizer _ASR;
	private SpeechSynthesis _TTS;
	
	private ButtonField _btnRecord;
	private ButtonField _btnWhatToSay;	
	private EditField _txtBox;
	
	private HorizontalFieldManager _hfm = new HorizontalFieldManager();
	
	public ASRListForm() 
	{		
		setTitle("List Voice Recognition");
		_btnRecord = new ButtonField("Record",ButtonField.FOCUSABLE|ButtonField.CONSUME_CLICK|ButtonField.HCENTER);
		_btnRecord.setChangeListener(this);
		
		_btnWhatToSay = new ButtonField("Help",ButtonField.FOCUSABLE|ButtonField.CONSUME_CLICK|ButtonField.HCENTER);
		_btnWhatToSay.setChangeListener(this);
	
		
		_txtBox = new EditField (Field.NON_FOCUSABLE|Field.READONLY);		
		_txtBox.setPadding(new XYEdges(5,0,0,5));		
		_txtBox.setText("Press Record");
	
		add(_txtBox);
		
		_hfm.add(_btnRecord);
		_hfm.add(_btnWhatToSay);
		
		add(_hfm);
		
		try
		{		
			_ASR  = SpeechRecognizer.getInstance(Main.iSpeechSample._APIKey, Main.iSpeechSample._Production); 
			_ASR.setFreeForm(SpeechRecognizer.FREEFORM_DISABLED);	
			
			_TTS = SpeechSynthesis.getInstance(Main.iSpeechSample._APIKey,Main.iSpeechSample._Production);
		}
		catch (Exception e) {
			_txtBox.setText("Invalid API Key");
		}
		
		
		Dialog.alert("Say Check: \nStatus, Signal, Network, or Phone Number");
		
		
		
		//_SpeechRec.startRecordAndNotify(false, 5000, this); 
		// Will fire the SpeechRecognizerEvent.RECORDING_COMPLETE after 5 seconds
	}	
	
	//ASR Call Backs
	public void stateChanged(int event, int freeFormValue, Exception arg2) 
	{
		if(event == SpeechRecognizerEvent.RECORDING_COMPLETE)
		{			
			try 
			{				
				final SpeechResult result = _ASR.stopRecord();
				processText(result.Text);
				_txtBox.setText(result.Text);
				//result.Confidence
				//result.Text
				
			} catch ( Exception e) {}					
		}
		else if(event == SpeechRecognizerEvent.RECORDING_COMMITTED)
		{
			//Recording has been sent to iSpeech			
		}
		else if(event == SpeechRecognizerEvent.RECORDING_CANCELED)
		{
			//Recording has been Canceled 			
		}	
	}
	
	//TTS Call Backs
	public void stateChanged(int event, Exception exception) 
	{
		if(event == SpeechSynthesis.SpeechSynthesisEvent.PLAY_SUCCESSFUL)
		{
			
		}
		else if (event == SpeechSynthesis.SpeechSynthesisEvent.PLAY_STOPPED)
		{
			
		}
		else if (event == SpeechSynthesis.SpeechSynthesisEvent.PLAY_FAILURE)
		{
			
		}		
	}
	private void processText(String text)
	{
		try
		{
			if(text.indexOf("status") >-1)
			{
				read("Status :"+PhoneUtils.getSignal()+" :  "+ PhoneUtils.getNetwork()+ " : "+ PhoneUtils.getBattery());
			}
			else if(text.indexOf("signal")>-1)
			{			
				read(PhoneUtils.getSignal());
			}
			else if(text.indexOf("network")>-1)
			{
				read(PhoneUtils.getNetwork());
			}
			else if(text.indexOf("battery")>-1)
			{
				read(PhoneUtils.getBattery());
				
			}
			else if(text.indexOf("phone number")>-1)
			{
				String phoneNum = net.rim.blackberry.api.phone.Phone.getDevicePhoneNumber(false).toLowerCase();
				System.out.println(phoneNum);
				
				if (phoneNum.indexOf("unknown")== -1 && phoneNum.indexOf("null")== -1 && !phoneNum.equals(""))
					phoneNum = PhoneUtils.fragmentateNumber(phoneNum);
				
				read("phone number " +phoneNum);
			}
			else if(text.indexOf("dial")>-1)
			{
				int start = text.indexOf("dial")+4;
				read("Dialing : "+text.substring(start, text.length()));
			}
			else
				
			{
				UiApplication.getUiApplication().invokeLater(new Runnable(){
					
					public void run()
					{
						_txtBox.setText("No Results");
					}
				});
			}
		} 
		catch (final Exception e) 
		{		
			UiApplication.getUiApplication().invokeLater(new Runnable(){
				
				public void run()
				{
					_txtBox.setText("Error :"+e.toString());
				}
			});
		}
	}
	private void read(String text)
	{
		_TTS.speak(text, this, false);
	}

	public void fieldChanged(Field field, int context) 
	{
		if(field.equals(_btnRecord))
		{
			try
			{				 
				 String[] names = new String[] { "status", "signal", "network", "battery", "phone number" };
				 _ASR.addAlias("CHOICE", names);
				 _ASR.addCommand("check %CHOICE%");
				
				
				if(!_ASR.startRecordAndNotify(false, 4000,this))
				{
					_txtBox.setText("Could not start recording");
					return;
				}
				
			} catch (Exception e) 
			{
				_txtBox.setText("Error " + e.toString());
			}
		}
		else 	if(field.equals(_btnWhatToSay))
		{
			Dialog.alert("Say Check: \nStatus, Signal, Network, or Phone Number");
			
		}
		
	}
	
	public boolean onClose()
	{
		 this.close();
		 return true;
	}
}



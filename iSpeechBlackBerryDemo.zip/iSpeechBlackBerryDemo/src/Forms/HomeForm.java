package Forms;

import Main.iSpeechSample;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.container.MainScreen;

public class HomeForm extends MainScreen implements FieldChangeListener
{
	private ButtonField _btnASR;
	private ButtonField _btnTTS ;
	private ButtonField _btnASRFreeForm;
	private LabelField _key;
	
	public HomeForm()
	{
		this.setTitle("iSpeech SDK 1.0.6");
		_btnASR = new ButtonField("List Voice Recognition",ButtonField.CONSUME_CLICK|ButtonField.FOCUSABLE);
		_btnASR.setChangeListener(this);	
		
		_btnASRFreeForm = new ButtonField("Freeform Voice Recognition",ButtonField.CONSUME_CLICK|ButtonField.FOCUSABLE);
		_btnASRFreeForm.setChangeListener(this);	
		
		_btnTTS = new ButtonField("Text To Speech",ButtonField.CONSUME_CLICK|ButtonField.FOCUSABLE);
		_btnTTS.setChangeListener(this);		
		
		_key = new LabelField("API KEY: "+iSpeechSample._APIKey);
		_key.setMargin(5, 0, 0, 5);
		this.add(_btnASR);		
		this.add(_btnASRFreeForm);
		this.add(_btnTTS);
		this.add(_key);
	}

	public void fieldChanged(Field field, int context) 
	{
		if(field.equals(_btnASR))
		{
			UiApplication.getUiApplication().pushScreen(new ASRListForm());
		}
		else if(field.equals(_btnTTS))
		{
			UiApplication.getUiApplication().pushScreen(new TTSForm());
		}	
		else if(field.equals(_btnASRFreeForm))
		{
			UiApplication.getUiApplication().pushScreen(new ASRFreeForm());
		}
	}
	public boolean onClose()
	{
		  this.close();
		 return true;
	}
}

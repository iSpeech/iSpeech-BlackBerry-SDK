package Forms;



import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.XYEdges;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.ObjectChoiceField;
import net.rim.device.api.ui.container.HorizontalFieldManager;
import net.rim.device.api.ui.container.MainScreen;

import org.iSpeech.InvalidApiKeyException;
import org.iSpeech.SpeechSynthesis;
import org.iSpeech.SpeechSynthesis.SpeechSynthesisEvent;

public class TTSForm extends MainScreen implements SpeechSynthesisEvent,FieldChangeListener
{

	private EditField _txtInput;
	private ObjectChoiceField _choiceVoice;
	private ButtonField _btnConvert;
	private HorizontalFieldManager _hfm = new HorizontalFieldManager();
	private SpeechSynthesis _TTS;
	
	public TTSForm()
	{		
		setTitle("TTS");
		_choiceVoice = new ObjectChoiceField("Voice :",new String []{"English Female","English Male"});
		_btnConvert = new ButtonField ("Convert",ButtonField.FOCUSABLE|ButtonField.CONSUME_CLICK|ButtonField.HCENTER);
		_btnConvert.setChangeListener(this);
		
		_txtInput = new EditField (Field.FOCUSABLE|Field.EDITABLE);
		_txtInput.setPadding(new XYEdges(5,0,0,5));		
		
		add(_txtInput);
		add(_choiceVoice);
		_hfm.add(_btnConvert);
		add(_hfm);
	
		try 
		{
			_TTS=  SpeechSynthesis.getInstance(Main.iSpeechSample._APIKey,Main.iSpeechSample._Production);	
			
		} 
		catch (InvalidApiKeyException e) 
		{	
			_txtInput.setText("Invalid API Key");			
		}
		
		
	}
	//TTS Call Backs
	public void stateChanged(int event, Exception exception) 
	{
		if(event == SpeechSynthesis.SpeechSynthesisEvent.PLAY_SUCCESSFUL)
		{
			
		}
		else if (event == SpeechSynthesis.SpeechSynthesisEvent.PLAY_STOPPED)
		{
			
		}
		else if (event == SpeechSynthesis.SpeechSynthesisEvent.PLAY_FAILURE)
		{
			
		}		
	}

	public void fieldChanged(Field field, int context) 
	{
		if(field.equals(_btnConvert))
			read(_txtInput.getText());
		
	}
	public void read(String text)
	{
		if(_choiceVoice.getSelectedIndex() ==0)
			_TTS.setVoice("usenglishfemale");
		else
			_TTS.setVoice("usenglishmale");
		
		if(_TTS.speak(text,this,false) == false)
		{
			Dialog.alert("An Error Has Occured");
		}
	}		
	public boolean onClose()
	{
		 this.close();
		 return true;
	}

}

package Forms;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.XYEdges;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.ObjectChoiceField;
import net.rim.device.api.ui.container.HorizontalFieldManager;
import net.rim.device.api.ui.container.MainScreen;

import org.iSpeech.InvalidApiKeyException;
import org.iSpeech.SpeechRecognizer;
import org.iSpeech.SpeechRecognizer.SpeechRecognizerEvent;
import org.iSpeech.SpeechResult;

public class ASRFreeForm extends MainScreen implements SpeechRecognizerEvent, FieldChangeListener
{

	private ButtonField _btnRecord;
	private ObjectChoiceField _choiceRecordTime;
	private EditField _txtReturned;	

	private HorizontalFieldManager _hfm = new HorizontalFieldManager();
	private int[] _time = new int[] {5000,10000,15000,20000,30000};
	
	private SpeechRecognizer _ASR;
	
	public ASRFreeForm()
	{
		setTitle("Freeform Voice Recognition");
		_btnRecord = new ButtonField("Record",ButtonField.FOCUSABLE|ButtonField.CONSUME_CLICK|ButtonField.HCENTER);
		_btnRecord.setChangeListener(this);	

		_choiceRecordTime = new ObjectChoiceField ("Record for :",new String []{"5 Sec","10 Sec","20 Sec","30 Sec"});
		_txtReturned = new EditField (Field.NON_FOCUSABLE|Field.READONLY);		
		_txtReturned.setPadding(new XYEdges(5,0,0,5));		
		_txtReturned.setText("Press Record");

		add(_txtReturned);
		add(_choiceRecordTime);
		_hfm.add(_btnRecord);
		
		add(_hfm);
		
		try 
		{			
			_ASR =  SpeechRecognizer.getInstance(Main.iSpeechSample._APIKey,Main.iSpeechSample._Production);
			_ASR.setFreeForm(SpeechRecognizer.FREEFORM_SMS);
		} 
		catch (InvalidApiKeyException e) {
			_txtReturned.setText("Invaild API Key");
		}	
		
	}

	//ASR Call Backs
	public void stateChanged(int event, int freeFormValue, Exception arg2) 
	{
		if(event == SpeechRecognizerEvent.RECORDING_COMPLETE)
		{			
			try 
			{				
				final SpeechResult result = _ASR.stopRecord();
				if (result == null || result.Text == null)
					_txtReturned.setText("Error");
				else
					_txtReturned.setText("result: " + result.Text);
				invalidate();
				//result.Confidence
				//result.Text
				
			} catch ( Exception e) {}					
		}
		else if(event == SpeechRecognizerEvent.RECORDING_COMMITTED)
		{
			_txtReturned.setText("Recording Sent");
			//Recording has been sent to iSpeech			
		}
		else if(event == SpeechRecognizerEvent.RECORDING_CANCELED)
		{
			_txtReturned.setText("Recording Canceled");
			//Recording has been Canceled 			
		}	
	}

	public void fieldChanged(Field field, int context) 
	{
		if(field.equals(_btnRecord))
		{
			try {
				_ASR.startRecordAndNotify(false, _time[_choiceRecordTime.getSelectedIndex()], this);
			} catch (Exception e) {
				_txtReturned.setText("Could not start recording");
			}
		}
		
	}
	public boolean onClose()
	{
		  this.close();
		 return true;
	}

}

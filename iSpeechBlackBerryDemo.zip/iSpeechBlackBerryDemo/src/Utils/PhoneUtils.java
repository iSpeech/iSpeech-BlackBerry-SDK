package Utils;

import net.rim.device.api.system.DeviceInfo;
import net.rim.device.api.system.RadioInfo;

public class PhoneUtils 
{
	public static String getSignal()
	{
		try
		{
			int level =  RadioInfo.getSignalLevel();
			level += 121;
			
			if(level < 0)
			{
				return "Signal : 0 percent" ;				
			}
			level =  (int) (level * (100/80.0));
		
			return "Signal level: " + level+" percent";									
		}
		catch (Exception e) 
		{}
		
		return "Signal error";
	}
	public static String getNetwork()
	{
		if(RadioInfo.getNetworkType() == RadioInfo.NETWORK_CDMA)						
		{
			return "Network Type : C D M A";
		}
		else if(RadioInfo.getNetworkType() == RadioInfo.NETWORK_GPRS)						
		{
			return "Network Type : G P R S";
		}
		else if(RadioInfo.getNetworkType() == RadioInfo.NETWORK_IDEN)						
		{
			return "Network Type : i den";
		}
		else if(RadioInfo.getNetworkType() == RadioInfo.NETWORK_802_11)						
		{
			return "Network Type : Wireless";
		}
		else if(RadioInfo.getNetworkType() == RadioInfo.NETWORK_UMTS)						
		{
			return "Network Type : U M T S";
		}		
		else
		{		
			return "Network Type : Unknown";
		}		
	}
	public static String getBattery()
	{
		try
		{		
			return "Battery level: " + DeviceInfo.getBatteryLevel() +" percent";									
		}
		catch (Exception e) 
		{}
		
		return "Battery error";
	}
	public static String fragmentateNumber(String number)
    {
        StringBuffer fragmentedNumber = new StringBuffer();
        for (int i = 0; i < number.length(); i++)
        {
            fragmentedNumber.append(number.charAt(i));
            fragmentedNumber.append(' ');
        }
        fragmentedNumber.deleteCharAt(fragmentedNumber.length() - 1);

        return fragmentedNumber.toString();
    }

}
